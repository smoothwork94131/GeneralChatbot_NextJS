import { RoleGroup } from "./types/role"

export const Global:{
    utilites_group:RoleGroup[],
    is_message_stream: boolean
} = {
    utilites_group: [],
    is_message_stream: false
}