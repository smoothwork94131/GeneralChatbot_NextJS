export const SPREAD_SHEET_ID = process.env.SPREAD_SHEET_ID || '';
export const SHEET_RANGE = process.env.SHEET_RANGE || '';
export const GOOGLE_SHEETS_CLIENT_EMAIL = process.env.GOOGLE_SHEETS_CLIENT_EMAIL || '';
export const GOOGLE_SHEETS_PRIVATE_KEY = process.env.GOOGLE_SHEETS_PRIVATE_KEY || '';

export const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

export const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';